
#ifndef __MP3PLAY_H
#define __MP3PLAY_H

#include "stm32f10x.h"
#include "sdcard.h"
#include "Uart.h"
#include "string.h"
#include "diskio.h"
#include "ff.h"
#include "vs1003.h"
#include "JOYState.h"

void mp3_play(void);


#endif















