#ifndef _JOYState_H
#define _JOYState_H

#include <stdio.h>
#include "stm32f10x.h"
//#include "config.h"

#define USER_KEY_Port					      GPIOG
#define USER_KEY_Pin					      GPIO_Pin_6
#define USER_KEY_RCC_AHBPeriph			RCC_APB2Periph_GPIOG
/****************************************************************/
#define WAKEUP_KEY_Port					    GPIOA
#define WAKEUP_KEY_Pin					    GPIO_Pin_0
#define WAKEUP_KEY_RCC_AHBPeriph		RCC_APB2Periph_GPIOA
/****************************************************************/
#define JOY_A_KEY_Port					    GPIOC
#define JOY_A_KEY_Pin					      GPIO_Pin_0
#define JOY_A_KEY_RCC_AHBPeriph			RCC_APB2Periph_GPIOC

#define JOY_B_KEY_Port					    GPIOC
#define JOY_B_KEY_Pin					      GPIO_Pin_2
#define JOY_B_KEY_RCC_AHBPeriph			RCC_APB2Periph_GPIOC

#define JOY_C_KEY_Port					    GPIOC
#define JOY_C_KEY_Pin					      GPIO_Pin_1
#define JOY_C_KEY_RCC_AHBPeriph			RCC_APB2Periph_GPIOC

#define JOY_D_KEY_Port					    GPIOC
#define JOY_D_KEY_Pin					      GPIO_Pin_3
#define JOY_D_KEY_RCC_AHBPeriph			RCC_APB2Periph_GPIOC

#define JOY_CTR_KEY_Port				    GPIOG
#define JOY_CTR_KEY_Pin					    GPIO_Pin_8
#define JOY_CTR_KEY_RCC_AHBPeriph		RCC_APB2Periph_GPIOG 
/****************************************************************/
#define LED1_Port						        GPIOF
#define LED1_Pin						        GPIO_Pin_6
#define LED1_RCC_AHBPeriph			  	RCC_APB2Periph_GPIOF

#define LED2_Port					        	GPIOF
#define LED2_Pin					         	GPIO_Pin_7
#define LED2_RCC_AHBPeriph	   			RCC_APB2Periph_GPIOF

#define LED3_Port						        GPIOF
#define LED3_Pin						        GPIO_Pin_8
#define LED3_RCC_AHBPeriph			  	RCC_APB2Periph_GPIOF

#define LED4_Port						        GPIOF
#define LED4_Pin						        GPIO_Pin_9
#define LED4_RCC_AHBPeriph			  	RCC_APB2Periph_GPIOF

#define KEY0  GPIO_ReadInputDataBit(JOY_A_KEY_Port,JOY_A_KEY_Pin)//��ȡ����0
#define KEY1  GPIO_ReadInputDataBit(JOY_B_KEY_Port,JOY_B_KEY_Pin)//��ȡ����1
#define KEY2  GPIO_ReadInputDataBit(JOY_C_KEY_Port,JOY_C_KEY_Pin)//��ȡ����2 
#define KEY3  GPIO_ReadInputDataBit(JOY_D_KEY_Port,JOY_D_KEY_Pin)//��ȡ����3 
#define KEY4  GPIO_ReadInputDataBit(JOY_CTR_KEY_Port,JOY_CTR_KEY_Pin)//��ȡ����4

#define KEY_LEFT	4   //PC3
#define KEY_RIGHT	1   //PC0
#define KEY_UP 		3   //PC1
#define KEY_DOWN	2   //PC2
#define KEY_CTR	  5   //PG8

void JOYState_LED_GPIO_Init(void);
uint8_t Read_JOYState(void);
void Led_Toggle(uint8_t key);

#endif /*_JOYState_H*/
